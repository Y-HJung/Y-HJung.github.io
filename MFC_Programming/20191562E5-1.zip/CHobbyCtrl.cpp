﻿// CHobbyCtrl.cpp: 구현 파일
//

#include "pch.h"
#include "testE5-1.h"
#include "CHobbyCtrl.h"
#include "afxdialogex.h"

#include "MainFrm.h"
#include "testE5-1View.h"


// CHobbyCtrl 대화 상자

IMPLEMENT_DYNAMIC(CHobbyCtrl, CDialogEx)

CHobbyCtrl::CHobbyCtrl(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG_TEXTOUT, pParent)
	, m_strName(_T(""))
	, m_bSex(true)
{

}

CHobbyCtrl::~CHobbyCtrl()
{
}

void CHobbyCtrl::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_HOBBY, m_listHobby);
	DDX_Control(pDX, IDC_COMBO_SEX, m_cbSex);
	DDX_Text(pDX, IDC_EDIT_NAME, m_strName);
}


BEGIN_MESSAGE_MAP(CHobbyCtrl, CDialogEx)
	ON_CBN_SELCHANGE(IDC_COMBO_SEX, &CHobbyCtrl::OnSelchangeComboSex)
	ON_COMMAND(IDC_RADIO_MALE, &CHobbyCtrl::OnRadioMale)
	ON_COMMAND(IDC_RADIO_FEMALE, &CHobbyCtrl::OnRadioFemale)
	ON_LBN_SELCHANGE(IDC_LIST_HOBBY, &CHobbyCtrl::OnSelchangeListHobby)
	ON_BN_CLICKED(IDC_CHECK_READING, &CHobbyCtrl::OnClickedCheckReading)
	ON_BN_CLICKED(IDC_CHECK_FISHING, &CHobbyCtrl::OnClickedCheckFishing)
	ON_BN_CLICKED(IDC_CHECK_SPORTS, &CHobbyCtrl::OnClickedCheckSports)
	ON_BN_CLICKED(IDC_BUTTON_RESULT, &CHobbyCtrl::OnClickedButtonResult)
END_MESSAGE_MAP()


// CHobbyCtrl 메시지 처리기


BOOL CHobbyCtrl::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  여기에 추가 초기화 작업을 추가합니다.
	// 리스트 박스 초기화
	m_listHobby.AddString(_T("독서"));
	m_listHobby.AddString(_T("낚시"));
	m_listHobby.AddString(_T("운동"));

	((CButton*)GetDlgItem(IDC_RADIO_MALE))->SetCheck(TRUE);  // 라디오 박스 초기화
	m_cbSex.SetCurSel(GetDlgItemInt(IDC_RADIO_MALE));   // 콤보 박스 초기화

	m_bChecked[0] = m_bChecked[1] = m_bChecked[2] = false;

	return TRUE;  // return TRUE unless you set the focus to a control
				  // 예외: OCX 속성 페이지는 FALSE를 반환해야 합니다.
}


void CHobbyCtrl::OnSelchangeComboSex()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	int indexCb = m_cbSex.GetCurSel();

	if (indexCb == 0)      // '남자'가 선택됐을 경우
	{
		((CButton*)GetDlgItem(IDC_RADIO_MALE))->SetCheck(TRUE);    // 남자 라디오 버튼 체크
		((CButton*)GetDlgItem(IDC_RADIO_FEMALE))->SetCheck(FALSE);  // 여자 라디오 버튼 체크해제
		m_bSex = true;
	}
	else if (indexCb == 1)   // '여자'가 선택됐을 경우
	{
		((CButton*)GetDlgItem(IDC_RADIO_FEMALE))->SetCheck(TRUE);    // 여자 라디오 버튼 체크
		((CButton*)GetDlgItem(IDC_RADIO_MALE))->SetCheck(FALSE);     // 남자 라디오 버튼 체크해제
		m_bSex = false;
	}

}


// 남자 라디오 버튼이 눌렸을 경우
void CHobbyCtrl::OnRadioMale()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	if (m_bSex == true)
		m_cbSex.SetCurSel(0);
	else
	{
		m_cbSex.SetCurSel(0);
		m_bSex = true;
	}
}


void CHobbyCtrl::OnRadioFemale()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	if (m_bSex == false)
		m_cbSex.SetCurSel(1);
	else
	{
		m_cbSex.SetCurSel(1);
		m_bSex = false;
	}
}


void CHobbyCtrl::OnSelchangeListHobby()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	int indexList = m_listHobby.GetCurSel();
	
	switch (indexList)
	{
	case 0:
		if (m_bChecked[0] == false)
		{
			((CButton*)GetDlgItem(IDC_CHECK_READING))->SetCheck(true);
			m_bChecked[0] = true;
		}
		else
		{
			((CButton*)GetDlgItem(IDC_CHECK_READING))->SetCheck(false);
			m_bChecked[0] = false;
		}
		break;
	case 1:
		if (m_bChecked[1] == false)
		{
			((CButton*)GetDlgItem(IDC_CHECK_FISHING))->SetCheck(true);
			m_bChecked[1] = true;
		}
		else
		{
			((CButton*)GetDlgItem(IDC_CHECK_FISHING))->SetCheck(false);
			m_bChecked[1] = false;
		}
		break;
	case 2:
		if (m_bChecked[2] == false)
		{
			((CButton*)GetDlgItem(IDC_CHECK_SPORTS))->SetCheck(true);
			m_bChecked[2] = true;
		}
		else
		{
			((CButton*)GetDlgItem(IDC_CHECK_SPORTS))->SetCheck(false);
			m_bChecked[2] = false;
		}
		break;
	}
	
}


void CHobbyCtrl::OnClickedCheckReading()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	if (m_bChecked[0] == false)
	{
		m_listHobby.SetSel(0);
		m_bChecked[0] = true;
	}
	else
	{
		m_listHobby.SetSel(0, 0);
		m_bChecked[0] = false;
	}
}


void CHobbyCtrl::OnClickedCheckFishing()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	if (m_bChecked[1] == false)
	{
		m_listHobby.SetSel(1);
		m_bChecked[1] = true;
	}
	else
	{
		m_listHobby.SetSel(1, 0);
		m_bChecked[1] = false;
	}
}


void CHobbyCtrl::OnClickedCheckSports()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	if (m_bChecked[2] == false)
	{
		m_listHobby.SetSel(2);
		m_bChecked[2] = true;
	}
	else
	{
		m_listHobby.SetSel(2, 0);
		m_bChecked[2] = false;
	}
}


void CHobbyCtrl::OnClickedButtonResult()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	CtestE51View* pView = (CtestE51View*)pFrame->GetActiveView();

	UpdateData(TRUE);
	if (m_strName.IsEmpty() == false)
	{
		pView->m_strName = _T("이름 : ") + m_strName;
		CString strSex;
		GetDlgItemText(IDC_COMBO_SEX, strSex);
		pView->m_strSex = _T("성별 : ") + strSex;

		CString strHb[3];
		CString strOut;
		if (m_bChecked[0] == true)
		{
			m_listHobby.GetText(0, strHb[0]);
		}
		if (m_bChecked[1] == true)
		{
			m_listHobby.GetText(1, strHb[1]);
		}
		if (m_bChecked[2] == true)
		{
			m_listHobby.GetText(2, strHb[2]);
		}
		if (!(m_bChecked[0] == false && m_bChecked[1] == false && m_bChecked[2] == false))
			strOut = _T("내가 선택한 취미 : ") + strHb[0] + _T(" ") + strHb[1] + _T(" ") + strHb[2];
		pView->m_strHobby = strOut;
	}
	else
	{
		AfxMessageBox(_T("이름을 입력하세요"));
	}

	pView->Invalidate();
	
}
