﻿// CHobbyOut.cpp: 구현 파일
//

#include "pch.h"
#include "testE5-1.h"
#include "CHobbyOut.h"


// CHobbyOut

IMPLEMENT_DYNAMIC(CHobbyOut, CDockablePane)

CHobbyOut::CHobbyOut()
{

}

CHobbyOut::~CHobbyOut()
{
}


BEGIN_MESSAGE_MAP(CHobbyOut, CDockablePane)
	ON_WM_CREATE()
END_MESSAGE_MAP()



// CHobbyOut 메시지 처리기




int CHobbyOut::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CDockablePane::OnCreate(lpCreateStruct) == -1)
		return -1;

	// TODO:  여기에 특수화된 작성 코드를 추가합니다.

	if (!m_ctrlHobby.Create(IDD_DIALOG_TEXTOUT, this))
	{
		TRACE0("문자열 출력 윈도우를 만들지 못했습니다.\n");
		return -1;
	}
	m_ctrlHobby.ShowWindow(SW_SHOW);

	return 0;
}
