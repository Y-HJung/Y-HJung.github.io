﻿#pragma once
#include "CHobbyCtrl.h"


// CHobbyOut

class CHobbyOut : public CDockablePane
{
	DECLARE_DYNAMIC(CHobbyOut)

public:
	CHobbyOut();
	virtual ~CHobbyOut();

protected:
	DECLARE_MESSAGE_MAP()
public:
	CHobbyCtrl m_ctrlHobby;
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
};


