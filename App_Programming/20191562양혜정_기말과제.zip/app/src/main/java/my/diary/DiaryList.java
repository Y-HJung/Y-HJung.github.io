package my.diary;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class DiaryList extends AppCompatActivity {

    DBManager dbManager;
    SQLiteDatabase sqLiteDatabase;

    String str_date;
    String str_title;
    String str_content;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diary_list);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("일기");

        TextView tv_date = (TextView)findViewById(R.id.date);
        TextView tv_title = (TextView)findViewById(R.id.title);
        TextView tv_content = (TextView)findViewById(R.id.content);

        Intent it = getIntent();
        str_date = it.getStringExtra("it_date");

        try{
            dbManager = new DBManager(getApplicationContext());
            sqLiteDatabase = dbManager.getReadableDatabase();

            Cursor cursor = sqLiteDatabase.query("Diary", null, "date = ?", new String[]{str_date}, null, null, null, null);

            if(cursor.moveToNext()){
                str_title = cursor.getString(cursor.getColumnIndex("title"));
                str_content = cursor.getString(cursor.getColumnIndex("content"));
            }

            sqLiteDatabase.close();
            dbManager.close();
        } catch (SQLiteException e){
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }

        tv_date.setText(str_date);
        tv_title.setText(str_title);
        tv_content.setText(str_content);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_diary_list, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();

        if(id == R.id.action_settings){
            Intent it = new Intent(this, MainActivity.class);
            startActivity(it);
            finish();
            return true;
        } else if(id == R.id.action_settings2){
            Intent it = new Intent(this, DiaryWr.class);
            startActivity(it);
            finish();
            return true;
        } else if(id == R.id.action_settings3) {
            String sel_date = "";

            try {
                dbManager = new DBManager(this);
                sqLiteDatabase = dbManager.getReadableDatabase();
                Cursor cursor = sqLiteDatabase.query("Diary", null, "date = ?", new String[]{str_date}, null, null, null, null);

                if(cursor.moveToNext()){
                    sel_date = cursor.getString(cursor.getColumnIndex("date"));
                }

                sqLiteDatabase.close();
                dbManager.close();

            } catch (SQLiteException e){
                Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
            }

            Intent it = new Intent(this, DiaryCh.class);
            it.putExtra("it_date", sel_date);
            startActivity(it);
            finish();

        } else if(id == R.id.action_settings4) {
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder.setMessage("삭제하시겠어요?");
            alertDialogBuilder.setPositiveButton("취소", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Toast.makeText(DiaryList.this, "취소되었습니다.", Toast.LENGTH_SHORT).show();
                }
            });
            alertDialogBuilder.setNegativeButton("삭제", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Toast.makeText(DiaryList.this, "삭제되었습니다.", Toast.LENGTH_SHORT).show();
                    try {
                        dbManager = new DBManager(getApplicationContext());
                        sqLiteDatabase = dbManager.getReadableDatabase();
                        sqLiteDatabase.delete("Diary", "date = ?", new String[]{str_date});

                        sqLiteDatabase.close();
                        dbManager.close();
                    } catch (SQLiteException e){
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                    Intent it = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(it);
                    finish();
                }
            });
            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();
        }
        return super.onOptionsItemSelected(item);
    }
}
