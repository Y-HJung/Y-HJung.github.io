package my.diary;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class DiaryCh extends AppCompatActivity {
    TextView tv_date;
    EditText et_title, et_content;

    DBManager dbManager;
    SQLiteDatabase sqLiteDatabase;

    String str_date;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diary_ch);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("일기 수정");

        tv_date = (TextView)findViewById(R.id.date);
        et_title = (EditText)findViewById(R.id.title);
        et_content = (EditText)findViewById(R.id.content);

        Intent it = getIntent();
        str_date = it.getStringExtra("it_date");

        selData(str_date);
    }

    public void selData(String date){
        dbManager = new DBManager(this);
        sqLiteDatabase = dbManager.getReadableDatabase();

        Cursor cursor = sqLiteDatabase.query("Diary", null, "date = ?", new String[]{date}, null, null, null, null);
        if(cursor.moveToNext()){
            tv_date.setText(cursor.getString(cursor.getColumnIndex("date")));
            et_title.setText(cursor.getString(cursor.getColumnIndex("title")));
            et_content.setText(cursor.getString(cursor.getColumnIndex("content")));
        }
        sqLiteDatabase.close();
        dbManager.close();
    }

    public void save(View view){
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("수정하시겠어요?");
        alertDialogBuilder.setPositiveButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(DiaryCh.this, "취소되었습니다.", Toast.LENGTH_SHORT).show();
            }
        });
        alertDialogBuilder.setNegativeButton("수정", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(DiaryCh.this, "수정되었습니다.", Toast.LENGTH_SHORT).show();

                dbManager = new DBManager(getApplicationContext());
                sqLiteDatabase = dbManager.getWritableDatabase();

                String str_title = "";
                et_title = (EditText)findViewById(R.id.title);
                str_title = et_title.getText().toString();

                String str_content = "";
                et_content = (EditText)findViewById(R.id.content);
                str_content = et_content.getText().toString();

                try{
                    ContentValues contentValues = new ContentValues();
                    contentValues.put("title", str_title);
                    contentValues.put("content", str_content);

                    sqLiteDatabase.update("Diary", contentValues, "date = ?", new String[]{str_date});

                    sqLiteDatabase.close();
                    dbManager.close();

                    Intent it = new Intent(getApplicationContext(), DiaryList.class);
                    it.putExtra("it_date", str_date);
                    startActivity(it);
                    finish();

                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    public void delete(View v){
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("수정하지 않고 홈으로 돌아가시겠어요?\n\n(저장하지 않으면 작성중이던 내용은 복구할 수 없습니다)");
        alertDialogBuilder.setPositiveButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(DiaryCh.this, "취소되었습니다.", Toast.LENGTH_SHORT).show();
            }
        });
        alertDialogBuilder.setNegativeButton("홈으로", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(DiaryCh.this, "작성이 종료되었습니다.", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }
}
