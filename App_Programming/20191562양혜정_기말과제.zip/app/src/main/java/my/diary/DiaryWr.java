package my.diary;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class DiaryWr extends AppCompatActivity {

    DBManager dbManager;
    SQLiteDatabase sqLiteDatabase;

    String day = "";
    int mYear, mMonth, mDay;
    TextView date;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diary_wr);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("일기 작성");

        Date();
        date = findViewById(R.id.date);



    }

    public void Date(){
        StringBuilder time = new StringBuilder();

        Calendar cal = new GregorianCalendar();

        int dayNum = cal.get(Calendar.DAY_OF_WEEK);
        switch (dayNum) {
            case 1:
                day = "일";
                break;
            case 2:
                day = "월";
                break;
            case 3:
                day = "화";
                break;
            case 4:
                day = "수";
                break;
            case 5:
                day = "목";
                break;
            case 6:
                day = "금";
                break;
            case 7:
                day = "토";
                break;
        }

        time.append(String.format("%d년 %d월 %d일(%s)\n", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)+1, cal.get(Calendar.DAY_OF_MONTH), day));

        TextView result = (TextView)findViewById(R.id.date);
        result.setText(time.toString());
    }

    public void dClick(View v){

        Calendar cal = new GregorianCalendar();

        mYear = cal.get(Calendar.YEAR);
        mMonth = cal.get(Calendar.MONTH);
        mDay = cal.get(Calendar.DAY_OF_MONTH);

        int dayNum = cal.get(Calendar.DAY_OF_WEEK);

        switch (v.getId()){
            case R.id.celDate:
                new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        mYear = year;
                        mMonth = month;
                        mDay = dayOfMonth;
                        date.setText(String.format("%04d년 %02d월 %2d일", mYear, mMonth+1, mDay)
                        );
                    }
                }, mYear, mMonth, mDay).show();
                break;
        }

    }

    public void save(View v){
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("저장하시겠어요?");
        alertDialogBuilder.setPositiveButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(DiaryWr.this, "취소되었습니다.", Toast.LENGTH_SHORT).show();
            }
        });
        alertDialogBuilder.setNegativeButton("저장", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                Toast.makeText(DiaryWr.this, "저장되었습니다.", Toast.LENGTH_SHORT).show();

                TextView tv_date = (TextView)findViewById(R.id.date);
                String str_date = tv_date.getText().toString();

                EditText et_title = (EditText)findViewById(R.id.title);
                String str_title = et_title.getText().toString();

                EditText et_content = (EditText)findViewById(R.id.content);
                String str_content = et_content.getText().toString();

                try{
                    dbManager = new DBManager(getApplicationContext());
                    sqLiteDatabase = dbManager.getWritableDatabase();

                    ContentValues values = new ContentValues();
                    values.put("date", str_date);
                    values.put("title", str_title);
                    values.put("content", str_content);

                    sqLiteDatabase.insert("Diary", null, values);

                    sqLiteDatabase.close();
                    dbManager.close();

                    Intent it = new Intent(getApplicationContext(), DiaryList.class);
                    it.putExtra("it_date", str_date);
                    startActivity(it);
                    finish();

                } catch(SQLiteException e){
                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }

        });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    public void delete(View v){
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("내용을 지우고 홈으로 돌아가시겠어요?\n\n(저장하지 않으면 작성중이던 내용은 복구할 수 없습니다)");
        alertDialogBuilder.setPositiveButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(DiaryWr.this, "취소되었습니다.", Toast.LENGTH_SHORT).show();
            }
        });
        alertDialogBuilder.setNegativeButton("홈으로", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(DiaryWr.this, "작성이 종료되었습니다.", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }
}
