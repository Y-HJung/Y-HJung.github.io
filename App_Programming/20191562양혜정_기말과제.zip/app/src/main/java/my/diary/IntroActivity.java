package my.diary;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class IntroActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);

        Handler x = new Handler();
        x.postDelayed(new IntroHandler(), 1500);

        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();
    }

    class IntroHandler implements Runnable{

        @Override
        public void run(){
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
            finish();
        }
    }
}
