package my.diary;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.MenuItemCompat;

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class MainActivity extends AppCompatActivity  implements View.OnClickListener {

    DBManager dbManager;
    SQLiteDatabase sqLiteDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        LinearLayout layout = (LinearLayout)findViewById(R.id.diary);

        try {
            dbManager = new DBManager(this);
            sqLiteDatabase = dbManager.getReadableDatabase();
            Cursor cursor = sqLiteDatabase.query("Diary", null, null, null, null, null, null);

            int i = 0;
            while(cursor.moveToNext()){
                String str_date = cursor.getString(cursor.getColumnIndex("date"));
                String str_title = cursor.getString(cursor.getColumnIndex("title"));

                LinearLayout layout_item = new LinearLayout(this);
                layout_item.setOrientation(LinearLayout.VERTICAL);
                layout_item.setPadding(10, 5, 10, 5);
                layout_item.setId(i);
                layout_item.setTag(str_date);

                TextView tv_date = new TextView(this);
                tv_date.setText(str_date);
                tv_date.setTextSize(15);
                tv_date.setTextColor(Color.rgb(186, 186, 186));
                layout_item.addView(tv_date);

                TextView tv_title = new TextView(this);
                tv_title.setText(str_title);
                tv_title.setTextSize(25);
                layout_item.addView(tv_title);

                layout_item.setOnClickListener(this);

                layout.addView(layout_item);

                i++;
            }

            cursor.close();
            sqLiteDatabase.close();
            dbManager.close();
        } catch (SQLiteException e){
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onClick(View view){
        int id = view.getId();

        LinearLayout layout_item = (LinearLayout)findViewById(id);
        String str_date = (String)layout_item.getTag();

        Intent it = new Intent(this, DiaryList.class);
        it.putExtra("it_date", str_date);
        startActivity(it);
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected (MenuItem item){
        int id = item.getItemId();

        if(id==R.id.action_settings) {
            Intent it = new Intent(this, DiaryWr.class);
            startActivity(it);
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}