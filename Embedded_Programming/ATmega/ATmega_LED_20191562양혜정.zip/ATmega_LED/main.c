/*
 * ATmega_LED.c
 *
 * Created: 2021-06-03 오전 10:09:55
 * Author : hyeju
 */ 

#include <avr/io.h>

void delay_sec(float sec){
	volatile int i, j, a;
	for(i=0; i<sec; i++){
		for(j=0; j<700; j++){
			for(a=0; a<700; a++);
		}
	}
		
}


int main(void)
{
	DDRA = 0xff;
	unsigned char count = 0;
	
    while (1) 
    { 
		count = count + 1;
		PORTA = count;
		delay_sec(0.7);
    }
}

